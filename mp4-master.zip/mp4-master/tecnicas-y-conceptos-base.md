# Técnicas y conceptos base

### Progresive Enhancement

Es una metodología o un principio que rige la programación para hacer accesible la aplicación a una gran variedad de navegadores. Ese fin se conseguirá desarrollando desde la base características \(features\) compatibles con todos ellos y luego añadiendo capas de mejora de forma progresiva para aquellos navegadores que las puedas procesar.

## Toallitas reutilizables

Hola hola que tal

1. hola
2. hola
3. hola
4. hola







