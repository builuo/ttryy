# Table of contents

* [Initial page](README.md)
* [Técnicas y conceptos base](tecnicas-y-conceptos-base.md)
* [Cosmetica](cosmetica/README.md)
  * [champú](cosmetica/champu/README.md)
    * [champu 1](cosmetica/champu/champu-1.md)
  * [desodorante](cosmetica/desodorante.md)

