//This is DoingSome.js code
$(document).ready( function(){
	console.log("hola caracola");
});